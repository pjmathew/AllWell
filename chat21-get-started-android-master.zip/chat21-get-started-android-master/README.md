Chat21 is the core of the open source live chat platform [Tiledesk.com](http://www.tiledesk.com).

# get-started-tutorial-android
The Android Get started tutorial

Please refer to this tutorial to setup and run this project:

[Get Started Tutorial - Android](http://www.chat21.org/docs/android/get-started/)
