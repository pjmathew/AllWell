# v.: 1.0.5 b.: 6
- updated with last library changes (chat sdk v.: 1.0.10 b.:38)

# v.: 1.0.4 b.: 5
- updated with last library changes (chat sdk v.: 1.0.5 b.:32)

# v.: 1.0.3 b.: 4
- fixed glide crash

# v.: 1.0.2 b.: 3
- updated chat21 sdk to v.: 1.0.3 b.: 30

# v.: 1.0.1 b.: 2
- signin with email and password